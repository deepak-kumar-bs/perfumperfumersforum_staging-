ALTER TABLE `engine4_sesbasic_usergateways` ADD `gateway_type` VARCHAR(64) NULL DEFAULT NULL;
