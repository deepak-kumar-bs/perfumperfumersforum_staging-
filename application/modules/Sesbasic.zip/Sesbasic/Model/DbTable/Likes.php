<?php

class Sesbasic_Model_DbTable_Likes extends Engine_Db_Table {

  protected $_rowClass = 'Sesbasic_Model_Like';

}
