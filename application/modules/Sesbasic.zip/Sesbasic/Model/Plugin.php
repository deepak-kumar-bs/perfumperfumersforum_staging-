<?php

class Sesbasic_Model_Plugin extends Core_Model_Item_Abstract {

  protected $_searchTriggers = false;

}